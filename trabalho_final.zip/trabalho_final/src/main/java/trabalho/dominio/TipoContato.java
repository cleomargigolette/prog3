/**
 * 
 */
package trabalho.dominio;

/**
 * @author cleomar
 *
 */
public enum TipoContato {
	
	EMAIL,
	PHONE;

}
