package trabalho.acoes;

public interface Acoes {

	public void executar();
	
}
