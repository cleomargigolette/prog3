package trabalho.gui.menu;

public interface Menu {
	
	public void exibe();
	public void executarOpcao(int opcao);

}
