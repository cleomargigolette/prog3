package com.company;

public class Medicao {

    private double ping;
    private double taxaDownload;
    private double taxaUpload;

    public double getPing() {
        return ping;
    }

    public void setPing(double ping) {
        this.ping = ping;
    }

    public double getTaxaDownload() {
        return taxaDownload;
    }

    public void setTaxaDownload(double taxaDownload) {
        this.taxaDownload = taxaDownload;
    }

    public double getTaxaUpload() {
        return taxaUpload;
    }

    public void setTaxaUpload(double taxaUpload) {
        this.taxaUpload = taxaUpload;
    }
}
